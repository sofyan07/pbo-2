
package GUI;
import java.io.File;
import java.io.IOException;
public class DemoBacaDirektori {
    public static void main (String[] args)throws IOException{
        File dir = new File("E:/Latihan_GUI");
        if(dir.isDirectory()) {
            File[] files = dir.listFiles();
            for(File f : files)
                System.out.println(f.getName());
        }
    }
}
