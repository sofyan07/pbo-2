
package GUI;
import java.io.FileWriter;
import java.io.IOException;
public class DemoTulisFile {
    public static void main(String args[])throws IOException{
        FileWriter fw = new FileWriter("E:/Latihan_GUI/contoh.txt");
        fw.write("Selamat Datang!");
        fw.close();
        System.out.println("Berhasil...");
        
    }
}
